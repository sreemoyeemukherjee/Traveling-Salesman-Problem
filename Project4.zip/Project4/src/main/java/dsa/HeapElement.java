/**Name: Sreemoyee Mukherjee
 * Andrew ID: sreemoym
 * Course: Data Structures & Algorithms
 * Assignment Number: 4
 */
package dsa;

// POJO for a heap element
public class HeapElement {
    // data fields
    Double weight;
    int vertex;

    // constructor
    public HeapElement() {
        weight = 0.0;
        vertex = 0;
    }
}
